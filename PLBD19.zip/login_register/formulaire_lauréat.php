<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Plateforme de Mentorat</title>
<link rel="stylesheet" href="style_fourmulaire_Lauréat.css">

</head>

<body>
    <header>
       <button width="150" onclick="deconnexion()">Déconnexion</button>
    </header>
    <p align="center">Bienvenue veuillez remplir ce formulaire</p>
    <iframe src="https://docs.google.com/forms/d/e/1FAIpQLSdKIj1SUIpFUzihO5avq68UULX0mbfopH1KBnCtE9GYoc4s2A/viewform?embedded=true" style="border: 0" width="600" height="600" frameborder="0" scrolling="yes"></iframe>


    <!-- JavaScript pour la déconnexion -->
    <script>
        function deconnexion() {
            // Mettez ici le code pour déconnecter l'utilisateur, comme une redirection vers la page de connexion par exemple
            alert("Vous avez été déconnecté(e) !");
            window.location.href = "page1.html"; // Redirection vers la page de connexion
        }
    </script>

    
</body>
</html>