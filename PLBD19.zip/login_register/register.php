<?php
session_start();

// Vérifier si le formulaire d'inscription a été soumis
if (isset($_POST["submit"])) {
   $username = $_POST["username"];
   $email = $_POST["email"];
   $password = $_POST["password"];
   $passwordRepeat = $_POST["repeat_password"];
   $role = $_POST["role"];

   $passwordHash = password_hash($password, PASSWORD_DEFAULT);

   $errors = array();
   
   // Validation des champs du formulaire
   if (empty($username) || empty($email) || empty($password) || empty($passwordRepeat)) {
      array_push($errors,"All fields are required");
   }
   if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      array_push($errors, "Email is not valid");
   }
   if (strlen($password) < 8) {
      array_push($errors,"Password must be at least 8 characters long");
   }
   if ($password !== $passwordRepeat) {
      array_push($errors,"Passwords do not match");
   }

   // Vérifier si l'email existe déjà dans la base de données avec le même rôle
   require_once "database.php";
   $sql = "SELECT * FROM user WHERE email = ? AND username=? AND role = ?";
   $stmt = mysqli_stmt_init($conn);
   if (mysqli_stmt_prepare($stmt, $sql)) {
      mysqli_stmt_bind_param($stmt, "sss", $email,$username, $role);
      mysqli_stmt_execute($stmt);
      mysqli_stmt_store_result($stmt);
      if (mysqli_stmt_num_rows($stmt) > 0) {
         array_push($errors, "cet utilisateur existe déja fait le login!");
      }
   } else {
      array_push($errors, "Database error");
   }

   // S'il n'y a pas d'erreurs, insérer l'utilisateur dans la base de données
   if (count($errors) == 0) {
      $sql = "INSERT INTO user (username, email, password, role) VALUES (?, ?, ?, ?)";
      $stmt = mysqli_stmt_init($conn);
      if (mysqli_stmt_prepare($stmt, $sql)) {
         mysqli_stmt_bind_param($stmt, "ssss", $username, $email, $passwordHash, $role);
         mysqli_stmt_execute($stmt);

         // Redirection vers une page spécifique en fonction du rôle de l'utilisateur
         if ($role == '1A') {
            header("Location: formulaire_1A.php");
         } elseif ($role == 'Lauréat') {
            header("Location: formulaire_Lauréat.php");
         } elseif ($role == '3A_mentore') {
            header("Location: formulaire_3A_mentore.php");
         } elseif ($role == '3A_mentoré') {
            header("Location: formulaire_3A_mentoré.php");
         } else {
            // Redirection vers une page par défaut si le rôle n'est pas reconnu
            header("Location: default.php");
         }
         exit; // Assurez-vous de terminer l'exécution du script après la redirection
      } else {
         echo "Database error";
      }
   } else {
      // Afficher les erreurs s'il y en a
      foreach ($errors as $error) {
         echo "<div class='alert alert-danger'>$error</div>";
      }
   }
   
}
?>
