
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Plateforme de Mentorat</title>
<link rel="stylesheet" href="style_espace_mentore.css">

</head>
<body>
    <script><p align="center">bienvenue{{username}}</p></script>
    <section class="liste">
        <p> Ton mentore</p>
        <p>Email</p>
        <p>description</p>
    </section>
    <section class="agenda">
    <iframe src="https://calendar.google.com/calendar/embed?src=garehmalika%40gmail.com&ctz=UTC" style="border: 0" width="600" height="600" frameborder="0" scrolling="no"></iframe>
    </section>
    <button width="150" onclick="deconnexion()">Déconnexion</button>

    
    <script>
        function deconnexion() {
            // Mettez ici le code pour déconnecter l'utilisateur, comme une redirection vers la page de connexion par exemple
            alert("Vous avez été déconnecté(e) !");
            window.location.href = "page1.html"; // Redirection vers la page de connexion
        }
    </script>
    <div id="chat-container">
        <div class="chat-main">
          <div class="chat-header">
            <div class="chat-title">ton Mentore</div>
          </div>
          <div class="chat-messages">
            <div class="message-wrapper">
              <div class="message-sender">nom de ton mentor</div>
              <div class="message-content">
                Bonjour,
              </div>
              <small class="message-time">5:12 PM</small>
            </div>
            <div class="message-wrapper">
              <div class="message-sender">toi</div>
              <div class="message-content">
                Hi there, I can see your message!
              </div>
              <small class="message-time">5:15 PM</small>
            </div>
            <!-- Add more messages as needed -->
          </div>
          <div class="chat-send-box">
            <input type="text" id="chat-message-input" placeholder="Type your message..." autocomplete="off" />
            <button id="chat-send-btn" disabled>Send</button>
          </div>
        </div>
      </div>

    
</body>
</html>