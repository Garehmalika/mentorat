<?php
include 'database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    $query = "SELECT password, role FROM user WHERE (username = ? OR email = ?)";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        echo "Error preparing statement: " . $conn->error;
        exit();
    }

    $stmt->bind_param("ss", $username, $email);
    if (!$stmt->execute()) {
        echo "Error executing statement: " . $stmt->error;
        exit();
    }

    $result = $stmt->get_result();
    $found = false;
    while ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password']) && $row['role'] == $role) {
            $found = true;
            session_start();
            $_SESSION['role'] = $row['role'];
            break;
        }
    }

    if (!$found) {
        echo "Nom d'utilisateur, e-mail ou mot de passe incorrect";
        exit();
    }

    switch (trim($role)) { // Utiliser trim() pour enlever les espaces éventuels
        case '1A':
            header("Location: espace_1A.php");
            break;
        case 'Lauréat':
            header("Location: espace_Lauréat.php");
            break;
        case '3A_mentore':
            header("Location: espace_3A_mentore.php");
            break;
        case '3A_mentoré':
            header("Location: espace_3A_mentoré.php");
            break;
        default:
            echo "Rôle invalide"; // Ce message apparaîtra si aucune correspondance n'est trouvée
    }
    exit();
}
?>