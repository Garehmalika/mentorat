<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Default Page</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Default Page</h1>
        <p>Le rôle sélectionné n'a pas été reconnu. Vous avez été redirigé vers cette page par défaut.</p>
        <p>Assurez-vous de sélectionner un rôle valide lors de l'inscription.</p>
        <a href="login.html">Retour à la page de connexion</a>
    </div>
</body>
</html>